// const { Router } = require("express");
// const router = Router();
// const {postMercadoPago} = require("./controllers")

// router.post("/", postMercadoPago)

// module.exports = router;
